package com.augustart.launcher

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Grille d'icônes : cols colonnes x rows lignes, cellules de taille égale. */
class IconGrid(context: Context, private val cols: Int, private val rows: Int) : ViewGroup(context) {

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = View.MeasureSpec.getSize(widthMeasureSpec)
        val h = View.MeasureSpec.getSize(heightMeasureSpec)
        setMeasuredDimension(w, h)
        val cw = (w - paddingLeft - paddingRight) / cols
        val ch = (h - paddingTop - paddingBottom) / rows
        for (i in 0 until childCount) {
            getChildAt(i).measure(
                View.MeasureSpec.makeMeasureSpec(cw, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(ch, View.MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = (r - l - paddingLeft - paddingRight) / cols
        val ch = (b - t - paddingTop - paddingBottom) / rows
        for (i in 0 until childCount) {
            val col = i % cols
            val row = i / cols
            val x = paddingLeft + col * cw
            val y = paddingTop + row * ch
            getChildAt(i).layout(x, y, x + cw, y + ch)
        }
    }
}

/** Pages horizontales qui s'alignent automatiquement, comme l'écran d'accueil d'un iPhone. */
class SnapPager(context: Context) : HorizontalScrollView(context) {

    val container = LinearLayout(context)
    var pageWidth: Int = context.resources.displayMetrics.widthPixels
    var pageCount: Int = 1
    var currentPage: Int = 0
        private set
    var onPageChanged: ((Int) -> Unit)? = null
    private var startPage = 0

    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        container.orientation = LinearLayout.HORIZONTAL
        addView(container, FrameLayout.LayoutParams(WRAP, MATCH))
    }

    /** Effet entre les pages : none, zoom, cube ou stack. */
    var effect: String = "zoom"

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        if (pageWidth > 0) {
            val p = Math.round(l.toFloat() / pageWidth)
            if (p != currentPage) {
                currentPage = p
                onPageChanged?.invoke(p)
            }
        }
        refreshEffects()
        moveWallpaper(l)
    }

    /** Recalcule l'effet visuel de chaque page selon sa position à l'écran. */
    fun refreshEffects() {
        if (pageWidth <= 0) return
        for (i in 0 until container.childCount) {
            val child = container.getChildAt(i)
            val rel = ((child.left - scrollX).toFloat() / pageWidth).coerceIn(-1f, 1f)
            val a = Math.abs(rel)
            val density = resources.displayMetrics.density
            when (effect) {
                "zoom" -> {
                    child.pivotX = child.width / 2f
                    child.pivotY = child.height / 2f
                    child.scaleX = 1f - 0.12f * a
                    child.scaleY = 1f - 0.12f * a
                    child.alpha = 1f - 0.35f * a
                    child.rotationY = 0f
                }
                "cube" -> {
                    child.pivotX = if (rel > 0f) 0f else child.width.toFloat()
                    child.pivotY = child.height / 2f
                    child.cameraDistance = 14000f * density
                    child.rotationY = -90f * rel
                    child.scaleX = 1f
                    child.scaleY = 1f
                    child.alpha = 1f
                }
                "stack" -> {
                    child.pivotX = child.width / 2f
                    child.pivotY = child.height / 2f
                    child.scaleX = 1f - 0.06f * a
                    child.scaleY = 1f - 0.06f * a
                    child.alpha = 1f - 0.25f * a
                    child.elevation = if (a < 0.5f) 12f * density else 0f
                    child.rotationY = 0f
                }
                else -> {
                    child.scaleX = 1f
                    child.scaleY = 1f
                    child.alpha = 1f
                    child.rotationY = 0f
                }
            }
        }
    }

    /** Fait défiler doucement le fond d'écran avec les pages (effet parallaxe). */
    private fun moveWallpaper(x: Int) {
        val total = (pageCount - 1) * pageWidth
        val token = windowToken ?: return
        if (total <= 0) return
        try {
            val offset = (x.toFloat() / total).coerceIn(0f, 1f)
            WallpaperManager.getInstance(context).setWallpaperOffsets(token, offset, 0f)
        } catch (e: Exception) {
        }
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            startPage = currentPage
        }
        val handled = super.onTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
            val delta = scrollX - startPage * pageWidth
            val threshold = pageWidth * 0.15f
            val target = when {
                delta > threshold -> startPage + 1
                delta < -threshold -> startPage - 1
                else -> startPage
            }
            goTo(target)
        }
        return handled
    }

    fun goTo(page: Int) {
        val last = Math.max(0, pageCount - 1)
        val p = Math.min(Math.max(page, 0), last)
        smoothScrollTo(p * pageWidth, 0)
    }

    /** Place directement sur une page, sans animation. */
    fun jumpTo(page: Int) {
        val last = Math.max(0, pageCount - 1)
        val p = Math.min(Math.max(page, 0), last)
        scrollTo(p * pageWidth, 0)
        currentPage = p
        refreshEffects()
        moveWallpaper(scrollX)
    }
}

/** Petits points indiquant la page courante. */
class DotsView(context: Context) : View(context) {
    private var count = 1
    private var active = 0
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(count: Int, active: Int) {
        this.count = count
        this.active = active
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val r = context.dp(3).toFloat()
        val gap = context.dp(12).toFloat()
        val total = (count - 1) * gap
        var x = width / 2f - total / 2f
        val y = height / 2f
        for (i in 0 until count) {
            paint.color = if (i == active) Color.WHITE else Color.argb(110, 255, 255, 255)
            canvas.drawCircle(x, y, r, paint)
            x += gap
        }
    }
}

/**
 * Liste d'applications (icône + nom).
 * grouped = true : sections par lettre (Bibliothèque). false : liste simple (recherche).
 */
class AppList(context: Context, private val grouped: Boolean) : ListView(context) {

    var onOpen: ((AppEntry, View) -> Unit)? = null
    var onMenu: ((AppEntry) -> Unit)? = null

    private var rows: List<Any> = emptyList()

    private val listAdapter = object : BaseAdapter() {
        override fun getCount(): Int = rows.size

        override fun getItem(position: Int): Any = rows[position]

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getViewTypeCount(): Int = 2

        override fun getItemViewType(position: Int): Int = if (rows[position] is String) 0 else 1

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val item = rows[position]
            if (item is String) {
                val header = if (convertView is TextView) convertView else buildHeader()
                header.text = item
                return header
            }
            val app = item as AppEntry
            val row = if (convertView is LinearLayout) convertView else buildRow()
            val img = row.getChildAt(0) as ImageView
            val label = row.getChildAt(1) as TextView
            img.setImageBitmap(IconStore.map[app.key])
            label.text = app.label
            row.setOnClickListener { onOpen?.invoke(app, row) }
            row.setOnLongClickListener {
                onMenu?.invoke(app)
                true
            }
            return row
        }
    }

    init {
        divider = null
        dividerHeight = 0
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        selector = ColorDrawable(Color.TRANSPARENT)
        adapter = listAdapter
    }

    fun submit(apps: List<AppEntry>) {
        val out = ArrayList<Any>()
        if (grouped) {
            var last = ""
            for (a in apps) {
                val letter = letterOf(a.label)
                if (letter != last) {
                    out.add(letter)
                    last = letter
                }
                out.add(a)
            }
        } else {
            out.addAll(apps)
        }
        rows = out
        listAdapter.notifyDataSetChanged()
    }

    private fun letterOf(label: String): String {
        val c = label.trim().firstOrNull()
        if (c != null && c.isLetter()) {
            return c.uppercaseChar().toString()
        }
        return "#"
    }

    private fun buildHeader(): TextView {
        val c = context
        val tv = TextView(c)
        tv.setTextColor(Color.argb(200, 255, 255, 255))
        tv.textSize = 14f
        tv.typeface = android.graphics.Typeface.DEFAULT_BOLD
        tv.setPadding(c.dp(16), c.dp(14), c.dp(16), c.dp(4))
        return tv
    }

    private fun buildRow(): LinearLayout {
        val c = context
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(c.dp(12), c.dp(6), c.dp(12), c.dp(6))
        val img = ImageView(c)
        img.scaleType = ImageView.ScaleType.FIT_XY
        row.addView(img, LinearLayout.LayoutParams(c.dp(46), c.dp(46)))
        val tv = TextView(c)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 17f
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.leftMargin = c.dp(14)
        row.addView(tv, lp)
        return row
    }
}
