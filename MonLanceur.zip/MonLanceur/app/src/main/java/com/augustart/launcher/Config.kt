package com.augustart.launcher

/** Les réglages du launcher (stockés dans Store). */
class Config(private val store: Store) {

    /** iphone, samsung, pixel, xiaomi, minimal ou custom. */
    var preset: String
        get() = store.getString("preset", "iphone")
        set(value) {
            store.putString("preset", value)
        }

    /** squircle, circle, rounded ou square. */
    var shape: String
        get() = store.getString("shape", "squircle")
        set(value) {
            store.putString("shape", value)
        }

    /** 4 ou 5 colonnes. */
    var cols: Int
        get() = store.getInt("cols", 4)
        set(value) {
            store.putInt("cols", value)
        }

    /** 0 petite, 1 moyenne, 2 grande. */
    var iconSize: Int
        get() = store.getInt("iconSize", 1)
        set(value) {
            store.putInt("iconSize", value)
        }

    var labels: Boolean
        get() = store.getBool("labels", true)
        set(value) {
            store.putBool("labels", value)
        }

    var dock: Boolean
        get() = store.getBool("dock", true)
        set(value) {
            store.putBool("dock", value)
        }

    /** true : toutes les apps sont sur l'accueil (pas de Bibliothèque), comme sur Xiaomi. */
    var allOnHome: Boolean
        get() = store.getBool("allOnHome", false)
        set(value) {
            store.putBool("allOnHome", value)
        }

    /** none, zoom, cube ou stack. */
    var effect: String
        get() = store.getString("effect", "zoom")
        set(value) {
            store.putString("effect", value)
        }

    /** aurora, stars, bubbles ou waves. */
    var scene: String
        get() = store.getString("scene", "aurora")
        set(value) {
            store.putString("scene", value)
        }

    fun iconDp(): Int {
        return when (iconSize) {
            0 -> 52
            2 -> 66
            else -> 58
        }
    }

    fun applyPreset(name: String) {
        preset = name
        when (name) {
            "samsung" -> {
                shape = "rounded"
                cols = 5
                labels = true
                dock = true
                allOnHome = false
                iconSize = 1
            }
            "pixel" -> {
                shape = "circle"
                cols = 5
                labels = true
                dock = true
                allOnHome = false
                iconSize = 1
            }
            "xiaomi" -> {
                shape = "rounded"
                cols = 4
                labels = true
                dock = true
                allOnHome = true
                iconSize = 1
            }
            "minimal" -> {
                shape = "circle"
                cols = 4
                labels = false
                dock = true
                allOnHome = false
                iconSize = 0
            }
            else -> {
                shape = "squircle"
                cols = 4
                labels = true
                dock = true
                allOnHome = false
                iconSize = 1
            }
        }
    }
}
