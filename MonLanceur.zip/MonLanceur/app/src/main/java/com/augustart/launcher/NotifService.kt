package com.augustart.launcher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Lit les notifications du téléphone (après autorisation de l'utilisateur)
 * pour les afficher dans le centre de notifications du launcher.
 */
class NotifService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: NotifService? = null

        @Volatile
        var onChange: (() -> Unit)? = null
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        onChange?.invoke()
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        onChange?.invoke()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        onChange?.invoke()
    }
}
