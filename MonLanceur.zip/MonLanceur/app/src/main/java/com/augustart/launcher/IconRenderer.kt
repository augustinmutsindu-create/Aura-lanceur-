package com.augustart.launcher

import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build

/** Redessine toutes les icônes dans la forme choisie (squircle iPhone, rond Pixel, arrondi Samsung...). */
object IconRenderer {

    private fun squircle(size: Float): Path {
        val path = Path()
        val a = size / 2f
        val n = 5.0
        val steps = 140
        for (i in 0..steps) {
            val t = 2.0 * Math.PI * i / steps
            val ct = Math.cos(t)
            val st = Math.sin(t)
            val x = a + a * Math.signum(ct) * Math.pow(Math.abs(ct), 2.0 / n)
            val y = a + a * Math.signum(st) * Math.pow(Math.abs(st), 2.0 / n)
            if (i == 0) path.moveTo(x.toFloat(), y.toFloat()) else path.lineTo(x.toFloat(), y.toFloat())
        }
        path.close()
        return path
    }

    private fun roundRect(size: Float, ratio: Float): Path {
        val path = Path()
        val r = size * ratio
        path.addRoundRect(RectF(0f, 0f, size, size), r, r, Path.Direction.CW)
        return path
    }

    private fun shapePath(shape: String, size: Float): Path {
        return when (shape) {
            "circle" -> {
                val p = Path()
                p.addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW)
                p
            }
            "rounded" -> roundRect(size, 0.30f)
            "square" -> roundRect(size, 0.08f)
            else -> squircle(size)
        }
    }

    fun render(pm: PackageManager, app: AppEntry, size: Int, shape: String): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val d: Drawable? = try {
            pm.getActivityIcon(ComponentName(app.packageName, app.activityName))
        } catch (e: Exception) {
            null
        }

        if (d == null) {
            canvas.drawColor(0xFF8E8E93.toInt())
        } else if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
            // Les calques d'une icône adaptative mesurent 108 dp pour 72 dp visibles.
            val inset = (size * 0.25f).toInt()
            val bg = d.background
            val fg = d.foreground
            if (bg != null) {
                bg.setBounds(-inset, -inset, size + inset, size + inset)
                bg.draw(canvas)
            }
            if (fg != null) {
                fg.setBounds(-inset, -inset, size + inset, size + inset)
                fg.draw(canvas)
            }
        } else {
            canvas.drawColor(0xFFF2F2F7.toInt())
            val pad = (size * 0.14f).toInt()
            d.setBounds(pad, pad, size - pad, size - pad)
            d.draw(canvas)
        }

        // Masque de la forme choisie, aux bords lissés
        val mask = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        maskPaint.color = Color.WHITE
        Canvas(mask).drawPath(shapePath(shape, size.toFloat()), maskPaint)
        val paint = Paint()
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        canvas.drawBitmap(mask, 0f, 0f, paint)
        mask.recycle()
        return bmp
    }
}
