package com.augustart.launcher

import android.content.Context
import org.json.JSONArray

/** Mémorise les réglages, les apps de l'écran d'accueil et celles du Dock. */
class Store(context: Context) {
    private val prefs = context.getSharedPreferences("augustart", Context.MODE_PRIVATE)

    var seeded: Boolean
        get() = prefs.getBoolean("seeded", false)
        set(value) {
            prefs.edit().putBoolean("seeded", value).apply()
        }

    fun getString(name: String, def: String): String {
        return prefs.getString(name, def) ?: def
    }

    fun putString(name: String, value: String) {
        prefs.edit().putString(name, value).apply()
    }

    fun getInt(name: String, def: Int): Int {
        return prefs.getInt(name, def)
    }

    fun putInt(name: String, value: Int) {
        prefs.edit().putInt(name, value).apply()
    }

    fun getBool(name: String, def: Boolean): Boolean {
        return prefs.getBoolean(name, def)
    }

    fun putBool(name: String, value: Boolean) {
        prefs.edit().putBoolean(name, value).apply()
    }

    fun getList(name: String): MutableList<String> {
        val raw = prefs.getString(name, null) ?: return ArrayList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<String>()
            for (i in 0 until arr.length()) {
                out.add(arr.getString(i))
            }
            out
        } catch (e: Exception) {
            ArrayList()
        }
    }

    fun setList(name: String, list: List<String>) {
        val arr = JSONArray()
        for (s in list) {
            arr.put(s)
        }
        prefs.edit().putString(name, arr.toString()).apply()
    }
}
