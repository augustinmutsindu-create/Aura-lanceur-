package com.augustart.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/**
 * Panneau de réglages d'augustart : style du téléphone, icônes, effets, fond animé.
 * Il s'affiche par-dessus l'écran d'accueil (comme les autres panneaux du launcher).
 */
class SettingsPanel(
    private val ctx: Context,
    private val cfg: Config,
    private val actions: Actions
) {

    /** Ce que le launcher doit faire quand un réglage change. */
    interface Actions {
        /** Un style complet (iPhone, Samsung...) vient d'être appliqué. */
        fun onPreset()

        /** La forme ou la taille des icônes a changé : il faut redessiner les icônes. */
        fun onIconStyle()

        /** Colonnes, noms, Dock ou "tout sur l'accueil" ont changé. */
        fun onLayout()

        /** L'effet de transition entre les pages a changé. */
        fun onEffect()

        /** Mettre le fond animé comme fond d'écran. */
        fun onApplyWallpaper()

        /** Remettre l'écran d'accueil à zéro. */
        fun onResetHome()

        /** Fermer le panneau. */
        fun onClose()
    }

    val view = FrameLayout(ctx)
    val sheet = LinearLayout(ctx)
    private val scroll = ScrollView(ctx)
    private val body = LinearLayout(ctx)

    init {
        view.visibility = View.GONE
        view.setBackgroundColor(Color.argb(150, 0, 0, 0))
        view.setOnClickListener { actions.onClose() }

        sheet.orientation = LinearLayout.VERTICAL
        sheet.background = roundedBg(Color.argb(247, 28, 28, 32), ctx.dp(26).toFloat())
        sheet.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(10))
        sheet.isClickable = true

        val header = LinearLayout(ctx)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(ctx)
        title.text = "Réglages augustart"
        title.setTextColor(Color.WHITE)
        title.textSize = 20f
        title.typeface = Typeface.DEFAULT_BOLD
        header.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        val close = TextView(ctx)
        close.text = "OK"
        close.setTextColor(Color.parseColor("#7FB3FF"))
        close.textSize = 16f
        close.typeface = Typeface.DEFAULT_BOLD
        close.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(4), ctx.dp(8))
        close.setOnClickListener { actions.onClose() }
        header.addView(close, LinearLayout.LayoutParams(WRAP, WRAP))
        sheet.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        scroll.isVerticalScrollBarEnabled = false
        body.orientation = LinearLayout.VERTICAL
        scroll.addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        val scrollLp = LinearLayout.LayoutParams(MATCH, 0, 1f)
        scrollLp.topMargin = ctx.dp(6)
        sheet.addView(scroll, scrollLp)

        val height = (ctx.resources.displayMetrics.heightPixels * 0.78f).toInt()
        val lp = FrameLayout.LayoutParams(MATCH, height, Gravity.TOP)
        lp.leftMargin = ctx.dp(10)
        lp.rightMargin = ctx.dp(10)
        lp.topMargin = ctx.dp(40)
        view.addView(sheet, lp)
    }

    /** Reconstruit la liste des réglages (en gardant la position de défilement). */
    fun refresh() {
        val keep = scroll.scrollY
        body.removeAllViews()

        section("Style du téléphone")
        chips(
            listOf(
                "iphone" to "iPhone",
                "samsung" to "Samsung",
                "pixel" to "Pixel",
                "xiaomi" to "Xiaomi",
                "minimal" to "Minimal"
            ),
            cfg.preset
        ) { id ->
            cfg.applyPreset(id)
            actions.onPreset()
            refresh()
        }
        note("Un style règle d'un coup la forme des icônes, les colonnes et l'organisation de l'accueil.")

        section("Forme des icônes")
        chips(
            listOf(
                "squircle" to "Squircle",
                "circle" to "Rond",
                "rounded" to "Arrondi",
                "square" to "Carré"
            ),
            cfg.shape
        ) { id ->
            cfg.shape = id
            cfg.preset = "custom"
            actions.onIconStyle()
            refresh()
        }

        section("Taille des icônes")
        chips(
            listOf("0" to "Petite", "1" to "Moyenne", "2" to "Grande"),
            cfg.iconSize.toString()
        ) { id ->
            cfg.iconSize = id.toInt()
            cfg.preset = "custom"
            actions.onIconStyle()
            refresh()
        }

        section("Colonnes")
        chips(
            listOf("4" to "4 colonnes", "5" to "5 colonnes"),
            cfg.cols.toString()
        ) { id ->
            cfg.cols = id.toInt()
            cfg.preset = "custom"
            actions.onLayout()
            refresh()
        }

        section("Écran d'accueil")
        toggle("Afficher les noms des apps", cfg.labels) { on ->
            cfg.labels = on
            cfg.preset = "custom"
            actions.onLayout()
        }
        toggle("Afficher le Dock", cfg.dock) { on ->
            cfg.dock = on
            cfg.preset = "custom"
            actions.onLayout()
        }
        toggle("Toutes les apps sur l'accueil (sans Bibliothèque)", cfg.allOnHome) { on ->
            cfg.allOnHome = on
            cfg.preset = "custom"
            actions.onLayout()
        }

        section("Animation entre les pages")
        chips(
            listOf(
                "none" to "Aucune",
                "zoom" to "Zoom",
                "cube" to "Cube",
                "stack" to "Pile"
            ),
            cfg.effect
        ) { id ->
            cfg.effect = id
            actions.onEffect()
            refresh()
        }

        section("Fond d'écran animé")
        chips(
            listOf(
                "aurora" to "Aurore",
                "stars" to "Étoiles",
                "bubbles" to "Bulles",
                "waves" to "Vagues"
            ),
            cfg.scene
        ) { id ->
            // Le fond animé relit ce choix tout seul : il change en direct.
            cfg.scene = id
            refresh()
        }
        button("✨  Appliquer le fond animé", Color.parseColor("#2F6BFF")) {
            actions.onApplyWallpaper()
        }
        note("Android demande une confirmation : appuyez sur « Définir le fond d'écran ».")

        section("Entretien")
        button("Réinitialiser l'écran d'accueil", Color.argb(90, 255, 255, 255)) {
            actions.onResetHome()
        }

        scroll.post { scroll.scrollTo(0, keep) }
    }

    // ------------------------------------------------------------------ éléments

    private fun section(text: String) {
        val tv = TextView(ctx)
        tv.text = text.uppercase()
        tv.setTextColor(Color.argb(170, 255, 255, 255))
        tv.textSize = 12f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.letterSpacing = 0.06f
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = ctx.dp(16)
        lp.bottomMargin = ctx.dp(6)
        lp.leftMargin = ctx.dp(4)
        body.addView(tv, lp)
    }

    private fun note(text: String) {
        val tv = TextView(ctx)
        tv.text = text
        tv.setTextColor(Color.argb(140, 255, 255, 255))
        tv.textSize = 12f
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = ctx.dp(6)
        lp.leftMargin = ctx.dp(4)
        body.addView(tv, lp)
    }

    /** Une rangée de boutons "pastille" : celui qui est choisi est blanc. */
    private fun chips(options: List<Pair<String, String>>, selected: String, onPick: (String) -> Unit) {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        for (opt in options) {
            val id = opt.first
            val on = id == selected
            val chip = TextView(ctx)
            chip.text = opt.second
            chip.textSize = 12.5f
            chip.maxLines = 1
            chip.gravity = Gravity.CENTER
            chip.typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            chip.setTextColor(if (on) Color.rgb(20, 20, 24) else Color.WHITE)
            chip.background = roundedBg(
                if (on) Color.WHITE else Color.argb(55, 255, 255, 255),
                ctx.dp(14).toFloat()
            )
            chip.setOnClickListener { onPick(id) }
            val lp = LinearLayout.LayoutParams(0, ctx.dp(40), 1f)
            lp.leftMargin = ctx.dp(3)
            lp.rightMargin = ctx.dp(3)
            row.addView(chip, lp)
        }
        body.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun toggle(text: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(ctx.dp(4), ctx.dp(8), ctx.dp(4), ctx.dp(8))

        val tv = TextView(ctx)
        tv.text = text
        tv.setTextColor(Color.WHITE)
        tv.textSize = 15f
        row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))

        val sw = Switch(ctx)
        sw.isChecked = value
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        row.addView(sw, LinearLayout.LayoutParams(WRAP, WRAP))

        // Toucher la ligne entière bascule aussi le bouton
        row.setOnClickListener { sw.isChecked = !sw.isChecked }
        body.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun button(text: String, color: Int, onClick: () -> Unit) {
        val btn = TextView(ctx)
        btn.text = text
        btn.setTextColor(Color.WHITE)
        btn.textSize = 15f
        btn.typeface = Typeface.DEFAULT_BOLD
        btn.gravity = Gravity.CENTER
        btn.background = roundedBg(color, ctx.dp(14).toFloat())
        btn.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(MATCH, ctx.dp(46))
        lp.topMargin = ctx.dp(10)
        body.addView(btn, lp)
    }
}
