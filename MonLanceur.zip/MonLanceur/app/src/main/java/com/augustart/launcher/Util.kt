package com.augustart.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable

const val MATCH = -1
const val WRAP = -2

/** Convertit des dp en pixels. */
fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

/** Fond rectangulaire aux coins arrondis. */
fun roundedBg(color: Int, radiusPx: Float): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    d.cornerRadius = radiusPx
    return d
}

/** Fond rond. */
fun ovalBg(color: Int): GradientDrawable {
    val d = GradientDrawable()
    d.shape = GradientDrawable.OVAL
    d.setColor(color)
    return d
}

/** Une application installée (une entrée par activité de lancement). */
data class AppEntry(
    val label: String,
    val packageName: String,
    val activityName: String
) {
    val key: String get() = "$packageName/$activityName"
}

/** Icônes déjà dessinées (style iPhone), indexées par AppEntry.key. */
object IconStore {
    @Volatile
    var map: Map<String, Bitmap> = emptyMap()

    /** Forme et taille des icônes utilisées pour `map` (sert à savoir s'il faut tout redessiner). */
    @Volatile
    var style: String = ""
}
