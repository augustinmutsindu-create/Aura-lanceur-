package com.augustart.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService

/**
 * Fond d'écran animé augustart. La scène (aurore, étoiles, bulles, vagues)
 * se choisit dans les réglages du launcher.
 */
class AugustartWallpaper : WallpaperService() {

    override fun onCreateEngine(): Engine = SceneEngine()

    inner class SceneEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val prefs = applicationContext.getSharedPreferences("augustart", Context.MODE_PRIVATE)
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private val rnd = java.util.Random(7)

        private var visible = false
        private var w = 1
        private var h = 1
        private var xOff = 0f
        private var t = 0f

        private val starCount = 130
        private val sx = FloatArray(starCount)
        private val sy = FloatArray(starCount)
        private val sz = FloatArray(starCount)
        private val sp = FloatArray(starCount)

        private val bubbleCount = 26
        private val bx = FloatArray(bubbleCount)
        private val by = FloatArray(bubbleCount)
        private val br = FloatArray(bubbleCount)
        private val bs = FloatArray(bubbleCount)
        private val bp = FloatArray(bubbleCount)

        private val frame = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) {
                    handler.postDelayed(this, 33)
                }
            }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            if (visible) {
                handler.post(frame)
            } else {
                handler.removeCallbacks(frame)
            }
        }

        override fun onOffsetsChanged(
            xOffset: Float,
            yOffset: Float,
            xOffsetStep: Float,
            yOffsetStep: Float,
            xPixelOffset: Int,
            yPixelOffset: Int
        ) {
            xOff = xOffset
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(frame)
            super.onDestroy()
        }

        private fun seed() {
            for (i in 0 until starCount) {
                sx[i] = rnd.nextFloat() * w * 1.4f
                sy[i] = rnd.nextFloat() * h
                sz[i] = rnd.nextFloat()
                sp[i] = 0.3f + rnd.nextFloat() * 1.2f
            }
            for (i in 0 until bubbleCount) {
                bx[i] = rnd.nextFloat() * w
                by[i] = rnd.nextFloat() * (h + 200f)
                br[i] = 14f + rnd.nextFloat() * 46f
                bs[i] = 25f + rnd.nextFloat() * 70f
                bp[i] = rnd.nextFloat() * 6.28f
            }
        }

        private fun drawFrame() {
            val holder = surfaceHolder ?: return
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                val c = canvas
                if (c != null) {
                    if (c.width != w || c.height != h) {
                        w = Math.max(1, c.width)
                        h = Math.max(1, c.height)
                        seed()
                    }
                    t += 0.033f
                    when (prefs.getString("scene", "aurora")) {
                        "stars" -> drawStars(c)
                        "bubbles" -> drawBubbles(c)
                        "waves" -> drawWaves(c)
                        else -> drawAurora(c)
                    }
                }
            } catch (e: Exception) {
                // Image perdue ou surface fermée : on ignore, la suivante sera la bonne.
            } finally {
                val c2 = canvas
                if (c2 != null) {
                    try {
                        holder.unlockCanvasAndPost(c2)
                    } catch (e: Exception) {
                    }
                }
            }
        }

        private fun background(c: Canvas, c0: Int, c1: Int, c2: Int) {
            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(
                0f, 0f, 0f, h.toFloat(),
                intArrayOf(c0, c1, c2),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
            paint.shader = null
        }

        private fun drawAurora(c: Canvas) {
            background(c, Color.rgb(8, 10, 40), Color.rgb(20, 12, 60), Color.rgb(6, 24, 48))
            val palette = intArrayOf(
                Color.rgb(120, 60, 255),
                Color.rgb(0, 200, 180),
                Color.rgb(255, 80, 160),
                Color.rgb(60, 140, 255)
            )
            for (i in 0 until 4) {
                val ph = t * (0.35f + i * 0.13f) + i * 1.7f
                val cx = w * (0.5f + 0.42f * Math.sin(ph.toDouble()).toFloat()) - xOff * w * 0.25f
                val cy = h * (0.5f + 0.38f * Math.cos((ph * 0.8f + i).toDouble()).toFloat())
                val r = Math.max(w, h) * (0.45f + 0.08f * i)
                val col = palette[i]
                val inner = Color.argb(150, Color.red(col), Color.green(col), Color.blue(col))
                val outer = Color.argb(0, Color.red(col), Color.green(col), Color.blue(col))
                paint.shader = RadialGradient(cx, cy, r, inner, outer, Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, r, paint)
            }
            paint.shader = null
        }

        private fun drawStars(c: Canvas) {
            background(c, Color.rgb(2, 4, 16), Color.rgb(8, 10, 38), Color.rgb(24, 12, 48))
            paint.style = Paint.Style.FILL
            val span = w * 1.4f
            for (i in 0 until starCount) {
                var x = sx[i] - t * sp[i] * 14f
                x = ((x % span) + span) % span - w * 0.2f
                x -= xOff * w * 0.2f * sz[i]
                val twinkle = 0.55f + 0.45f * Math.sin((t * (1.5f + sz[i]) + i).toDouble()).toFloat()
                paint.color = Color.argb((255 * twinkle).toInt(), 255, 255, 255)
                c.drawCircle(x, sy[i], 0.8f + sz[i] * 1.6f, paint)
            }
            // Étoile filante toutes les 7 secondes
            val cycle = t % 7f
            if (cycle < 0.9f) {
                val p = cycle / 0.9f
                val x0 = w * 0.9f - p * w * 0.7f
                val y0 = h * 0.12f + p * h * 0.28f
                paint.strokeWidth = 3f
                paint.color = Color.argb((255 * (1f - p)).toInt(), 255, 255, 255)
                c.drawLine(x0, y0, x0 + 90f, y0 - 45f, paint)
            }
        }

        private fun drawBubbles(c: Canvas) {
            background(c, Color.rgb(8, 60, 90), Color.rgb(20, 40, 120), Color.rgb(50, 20, 110))
            val range = h + 200f
            for (i in 0 until bubbleCount) {
                val y = ((by[i] - t * bs[i]) % range + range) % range - 100f
                val x = bx[i] + 24f * Math.sin((t * 0.9f + bp[i]).toDouble()).toFloat() - xOff * w * 0.15f
                paint.style = Paint.Style.FILL
                paint.color = Color.argb(34, 255, 255, 255)
                c.drawCircle(x, y, br[i], paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f
                paint.color = Color.argb(110, 255, 255, 255)
                c.drawCircle(x, y, br[i], paint)
                paint.style = Paint.Style.FILL
                paint.color = Color.argb(150, 255, 255, 255)
                c.drawCircle(x - br[i] * 0.35f, y - br[i] * 0.35f, br[i] * 0.16f, paint)
            }
            paint.style = Paint.Style.FILL
        }

        private fun drawWaves(c: Canvas) {
            background(c, Color.rgb(255, 140, 80), Color.rgb(220, 70, 120), Color.rgb(60, 30, 110))
            paint.style = Paint.Style.FILL
            for (k in 0 until 4) {
                val base = h * (0.55f + k * 0.1f)
                val amp = 26f + k * 14f
                val speed = 0.6f + k * 0.25f
                path.reset()
                path.moveTo(0f, h.toFloat())
                var x = 0f
                while (x <= w + 20f) {
                    val angle = x / w * 6.0f + t * speed + k * 1.3f - xOff * 2f
                    val y = base + amp * Math.sin(angle.toDouble()).toFloat()
                    path.lineTo(x, y)
                    x += 20f
                }
                path.lineTo(w.toFloat(), h.toFloat())
                path.close()
                paint.color = Color.argb(70 + k * 30, 255, 255, 255 - k * 40)
                c.drawPath(path, paint)
            }
        }
    }
}
