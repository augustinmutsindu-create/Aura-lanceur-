package com.augustart.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.app.Dialog
import android.app.Notification
import android.app.WallpaperManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.service.notification.StatusBarNotification
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * augustart : un écran d'accueil façon iPhone.
 *
 * - Écran d'accueil paginé avec horloge, apps choisies et Dock
 * - Bibliothèque d'apps (dernière page) : toutes les apps classées de A à Z
 * - Glisser vers le bas au milieu de l'écran : recherche (Spotlight)
 * - Glisser vers le bas en haut à gauche : centre de notifications
 * - Glisser vers le bas en haut à droite : centre de contrôle
 * - Appui long sur une app : menu (accueil, Dock, infos, désinstaller)
 */
class MainActivity : Activity() {

    private lateinit var store: Store
    private lateinit var cfg: Config
    private lateinit var settings: SettingsPanel
    private var hasLibrary = true
    private var forceRebuild = false
    private var pendingEntrance = false
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()

    private var allApps: List<AppEntry> = emptyList()
    private var firstLoad = true
    private var topInset = 0
    private var bottomInset = 0
    private var iconPx = 0

    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var pager: SnapPager
    private lateinit var dots: DotsView
    private lateinit var dock: LinearLayout
    private lateinit var library: AppList
    private var batteryText: TextView? = null

    private lateinit var spotlight: FrameLayout
    private lateinit var spotSheet: LinearLayout
    private lateinit var spotInput: EditText
    private lateinit var spotHint: TextView
    private lateinit var spotList: AppList
    private var spotResults: List<AppEntry> = emptyList()

    private lateinit var notifPanel: FrameLayout
    private lateinit var notifSheet: LinearLayout
    private lateinit var notifBox: LinearLayout

    private lateinit var controlPanel: FrameLayout
    private lateinit var controlSheet: LinearLayout
    private lateinit var brightBar: SeekBar
    private lateinit var volumeBar: SeekBar
    private val tileRefreshers = ArrayList<() -> Unit>()
    private var torchOn = false
    private var askedWrite = false

    private lateinit var gestures: GestureDetector

    private val tick = object : Runnable {
        override fun run() {
            updateBattery()
            handler.postDelayed(this, 30000)
        }
    }

    // ------------------------------------------------------------------ cycle de vie

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        cfg = Config(store)
        iconPx = dp(cfg.iconDp())
        topInset = dp(28)

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        buildUi()
        setContentView(root)
        setupGestures()
        applyInsets()
        root.requestApplyInsets()
    }

    override fun onResume() {
        super.onResume()
        NotifService.onChange = {
            handler.post {
                if (notifPanel.visibility == View.VISIBLE) refreshNotifications()
            }
        }
        loadApps()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    override fun onDestroy() {
        NotifService.onChange = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Bouton Accueil : on ferme tout et on revient à la première page
        closeOverlays()
        pager.goTo(0)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (isOverlayVisible()) {
            closeOverlays()
        } else if (pager.currentPage != 0) {
            pager.goTo(0)
        }
        // Sur un launcher, "Retour" ne quitte jamais l'accueil.
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ------------------------------------------------------------------ construction de l'interface

    private fun buildUi() {
        root = FrameLayout(this)
        // Léger voile sombre pour que le texte reste lisible sur n'importe quel fond d'écran
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(90, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.argb(110, 0, 0, 0))
        )
        root.setOnApplyWindowInsetsListener { _, insets ->
            topInset = insets.systemWindowInsetTop
            bottomInset = insets.systemWindowInsetBottom
            applyInsets()
            insets
        }

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        root.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))

        pager = SnapPager(this)
        dots = DotsView(this)
        pager.onPageChanged = { page -> dots.set(pager.pageCount, page) }
        content.addView(pager, LinearLayout.LayoutParams(MATCH, 0, 1f))
        content.addView(dots, LinearLayout.LayoutParams(MATCH, dp(18)))

        // Bouton "Rechercher" au-dessus du Dock
        val pill = TextView(this)
        pill.text = "🔍  Rechercher"
        pill.setTextColor(Color.WHITE)
        pill.textSize = 13f
        pill.gravity = Gravity.CENTER
        pill.background = roundedBg(Color.argb(70, 0, 0, 0), dp(17).toFloat())
        pill.setOnClickListener { openSpotlight() }
        val pillLp = LinearLayout.LayoutParams(dp(150), dp(34))
        pillLp.gravity = Gravity.CENTER_HORIZONTAL
        pillLp.topMargin = dp(4)
        pillLp.bottomMargin = dp(10)
        content.addView(pill, pillLp)

        // Dock
        dock = LinearLayout(this)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER_VERTICAL
        dock.setPadding(dp(8), 0, dp(8), 0)
        dock.background = roundedBg(Color.argb(70, 255, 255, 255), dp(30).toFloat())
        val dockLp = LinearLayout.LayoutParams(MATCH, dp(84))
        dockLp.leftMargin = dp(12)
        dockLp.rightMargin = dp(12)
        dockLp.bottomMargin = dp(8)
        content.addView(dock, dockLp)

        buildSpotlight()
        buildNotifications()
        buildControl()
        buildSettings()
    }

    private fun applyInsets() {
        content.setPadding(0, topInset, 0, bottomInset)
    }

    // ------------------------------------------------------------------ geste

    private fun setupGestures() {
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (e1 == null || isOverlayVisible()) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dy) < dp(70) || abs(dy) < abs(dx) * 1.3f) return false

                val h = resources.displayMetrics.heightPixels
                val w = resources.displayMetrics.widthPixels
                val onLibrary = hasLibrary && pager.pageCount > 1 && pager.currentPage == pager.pageCount - 1

                if (dy > 0 && velocityY > 600f) {
                    val inTopZone = e1.y < topInset + h * 0.14f
                    if (inTopZone) {
                        if (e1.x > w * 0.5f) openControl() else openNotifications()
                        return true
                    }
                    if (!onLibrary) {
                        openSpotlight()
                        return true
                    }
                } else if (dy < 0 && velocityY < -800f && !onLibrary) {
                    if (hasLibrary) pager.goTo(pager.pageCount - 1) else openSpotlight()
                    return true
                }
                return false
            }
        })
        gestures.setIsLongpressEnabled(false)
    }

    // ------------------------------------------------------------------ applications

    private fun loadApps() {
        // Forme et taille lues ici, sur le fil principal, avant le travail en arrière-plan
        val px = iconPx
        val shape = cfg.shape
        val style = shape + "|" + px
        executor.execute {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN)
            query.addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name) }
                .sortedBy { it.label.lowercase() }

            // On garde les icônes déjà dessinées seulement si la forme et la taille n'ont pas changé
            val base: Map<String, Bitmap> = if (IconStore.style == style) IconStore.map else emptyMap()
            val icons = HashMap<String, Bitmap>(base)
            for (a in list) {
                if (!icons.containsKey(a.key)) {
                    icons[a.key] = IconRenderer.render(pm, a, px, shape)
                }
            }

            handler.post {
                val same = list.map { it.key } == allApps.map { it.key }
                IconStore.map = icons
                IconStore.style = style
                allApps = list
                if (!same || firstLoad || forceRebuild) {
                    if (!same || firstLoad) pendingEntrance = true
                    firstLoad = false
                    forceRebuild = false
                    seedDefaults()
                    rebuildAll()
                } else {
                    updateBattery()
                }
            }
        }
    }

    private fun rebuildAll() {
        rebuildPager()
        rebuildDock()
        updateSpotlight(spotInput.text.toString())
    }

    /** Au premier lancement : met les apps usuelles (téléphone, messages...) dans le Dock et l'accueil. */
    private fun seedDefaults() {
        if (store.seeded) return

        fun pkgOf(i: Intent): String? {
            return try {
                packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            } catch (e: Exception) {
                null
            }
        }

        val dockPackages = listOf(
            pkgOf(Intent(Intent.ACTION_DIAL)),
            pkgOf(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))),
            pkgOf(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))),
            pkgOf(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        )
        val dockKeys = ArrayList<String>()
        for (p in dockPackages) {
            if (p == null) continue
            val a = allApps.firstOrNull { it.packageName == p } ?: continue
            if (!dockKeys.contains(a.key)) dockKeys.add(a.key)
        }

        val candidates = ArrayList<String?>()
        candidates.add(pkgOf(Intent(Settings.ACTION_SETTINGS)))
        candidates.addAll(
            listOf(
                "com.android.vending", "com.google.android.apps.photos", "com.android.chrome",
                "com.whatsapp", "com.google.android.youtube", "com.google.android.gm",
                "com.google.android.apps.maps", "com.facebook.katana", "com.instagram.android",
                "org.telegram.messenger", "com.zhiliaoapp.musically",
                "com.google.android.calculator", "com.android.calculator2",
                "com.google.android.deskclock", "com.android.deskclock",
                "com.google.android.calendar", "com.google.android.contacts", "com.android.contacts"
            )
        )
        val homeKeys = ArrayList<String>()
        for (p in candidates) {
            if (p == null) continue
            val a = allApps.firstOrNull { it.packageName == p } ?: continue
            if (!dockKeys.contains(a.key) && !homeKeys.contains(a.key)) homeKeys.add(a.key)
        }

        store.setList("dock", dockKeys)
        store.setList("home", homeKeys)
        store.seeded = true
    }

    private fun launch(app: AppEntry, from: View?) {
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_LAUNCHER)
        intent.setClassName(app.packageName, app.activityName)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            if (from != null) {
                val opts = ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
                startActivity(intent, opts.toBundle())
            } else {
                startActivity(intent)
            }
            closeOverlays()
        } catch (e: Exception) {
            toast("Impossible d'ouvrir cette application")
        }
    }

    private fun startSafe(intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ écran d'accueil

    private fun makeIcon(app: AppEntry, showLabel: Boolean): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER

        val img = ImageView(this)
        img.setImageBitmap(IconStore.map[app.key])
        box.addView(img, LinearLayout.LayoutParams(iconPx, iconPx))

        if (showLabel) {
            val tv = TextView(this)
            tv.text = app.label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11f
            tv.maxLines = 1
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.gravity = Gravity.CENTER
            tv.setShadowLayer(4f, 0f, 1f, Color.argb(160, 0, 0, 0))
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dp(5)
            lp.leftMargin = dp(2)
            lp.rightMargin = dp(2)
            box.addView(tv, lp)
        }

        // Petite animation d'appui : l'icône se réduit puis rebondit
        box.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(OvershootInterpolator()).start()
            }
            false
        }
        box.setOnClickListener { launch(app, img) }
        box.setOnLongClickListener {
            box.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            showAppMenu(app)
            true
        }
        return box
    }

    private fun rebuildPager() {
        val keep = pager.currentPage
        val pw = resources.displayMetrics.widthPixels
        pager.pageWidth = pw
        pager.effect = cfg.effect
        pager.container.removeAllViews()
        hasLibrary = !cfg.allOnHome
        val animate = pendingEntrance
        pendingEntrance = false

        val homeApps = ArrayList<AppEntry>()
        for (k in store.getList("home")) {
            val a = allApps.firstOrNull { it.key == k }
            if (a != null && !homeApps.contains(a)) homeApps.add(a)
        }
        if (cfg.allOnHome) {
            // Mode "tout sur l'accueil" : les apps non rangées suivent à la fin
            for (a in allApps) {
                if (!homeApps.contains(a)) homeApps.add(a)
            }
        }

        // Page 1 : une rangée de moins (sous l'horloge), puis pages pleines. Colonnes réglables.
        val cols = cfg.cols
        val chunks = ArrayList<List<AppEntry>>()
        var i = 0
        var cap = cols * 4
        while (i < homeApps.size || chunks.isEmpty()) {
            chunks.add(homeApps.subList(i, Math.min(homeApps.size, i + cap)))
            i += cap
            cap = cols * 6
        }

        var index = 0
        for (n in chunks.indices) {
            val chunk = chunks[n]
            val grid = IconGrid(this, cols, if (n == 0) 4 else 6)
            grid.setPadding(dp(8), dp(4), dp(8), dp(4))
            grid.setOnLongClickListener {
                openSettings()
                true
            }
            for (a in chunk) {
                val icon = makeIcon(a, cfg.labels)
                grid.addView(icon)
                if (animate) {
                    icon.alpha = 0f
                    icon.scaleX = 0.7f
                    icon.scaleY = 0.7f
                    icon.animate().alpha(1f).scaleX(1f).scaleY(1f)
                        .setStartDelay(Math.min(index * 25, 600).toLong())
                        .setDuration(280)
                        .start()
                }
                index++
            }

            val page: View
            if (n == 0) {
                val col = LinearLayout(this)
                col.orientation = LinearLayout.VERTICAL
                col.setOnLongClickListener {
                    openSettings()
                    true
                }
                val widgetLp = LinearLayout.LayoutParams(MATCH, 0, 2f)
                widgetLp.setMargins(dp(14), dp(6), dp(14), dp(6))
                col.addView(buildWidget(), widgetLp)
                if (chunk.isEmpty()) {
                    val hint = TextView(this)
                    hint.text = "Appuyez longuement sur une app dans la Bibliothèque (page de droite) pour l'ajouter ici."
                    hint.setTextColor(Color.argb(220, 255, 255, 255))
                    hint.textSize = 14f
                    hint.gravity = Gravity.CENTER
                    hint.setPadding(dp(30), 0, dp(30), 0)
                    col.addView(hint, LinearLayout.LayoutParams(MATCH, 0, 4f))
                } else {
                    col.addView(grid, LinearLayout.LayoutParams(MATCH, 0, 4f))
                }
                page = col
            } else {
                page = grid
            }
            pager.container.addView(page, LinearLayout.LayoutParams(pw, MATCH))
        }

        if (hasLibrary) {
            pager.container.addView(buildLibraryPage(), LinearLayout.LayoutParams(pw, MATCH))
            library.submit(allApps)
        }
        pager.pageCount = chunks.size + (if (hasLibrary) 1 else 0)
        updateBattery()

        val target = Math.min(keep, pager.pageCount - 1)
        dots.set(pager.pageCount, target)
        pager.post { pager.jumpTo(target) }
    }

    private fun rebuildDock() {
        dock.removeAllViews()
        dock.visibility = if (cfg.dock) View.VISIBLE else View.GONE
        val apps = ArrayList<AppEntry>()
        for (k in store.getList("dock")) {
            val a = allApps.firstOrNull { it.key == k }
            if (a != null) apps.add(a)
        }
        for (a in apps.take(4)) {
            dock.addView(makeIcon(a, false), LinearLayout.LayoutParams(0, MATCH, 1f))
        }
    }

    private fun buildWidget(): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(20), dp(10), dp(20), dp(10))
        card.background = roundedBg(Color.argb(95, 0, 0, 0), dp(24).toFloat())

        val date = TextClock(this)
        date.format12Hour = "EEEE d MMMM"
        date.format24Hour = "EEEE d MMMM"
        date.setTextColor(Color.argb(230, 255, 255, 255))
        date.textSize = 15f

        val time = TextClock(this)
        time.format12Hour = "HH:mm"
        time.format24Hour = "HH:mm"
        time.setTextColor(Color.WHITE)
        time.textSize = 52f
        time.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)

        val battery = TextView(this)
        battery.setTextColor(Color.argb(220, 255, 255, 255))
        battery.textSize = 14f
        batteryText = battery

        card.addView(date, LinearLayout.LayoutParams(WRAP, WRAP))
        card.addView(time, LinearLayout.LayoutParams(WRAP, WRAP))
        card.addView(battery, LinearLayout.LayoutParams(WRAP, WRAP))
        return card
    }

    private fun updateBattery() {
        val tv = batteryText ?: return
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        tv.text = (if (charging) "⚡ " else "🔋 ") + pct + " %"
    }

    private fun buildLibraryPage(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(10), dp(16), dp(4))

        val title = TextView(this)
        title.text = "Bibliothèque d'apps"
        title.setTextColor(Color.WHITE)
        title.textSize = 26f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setShadowLayer(6f, 0f, 1f, Color.argb(160, 0, 0, 0))
        val titleLp = LinearLayout.LayoutParams(MATCH, WRAP)
        titleLp.leftMargin = dp(6)
        titleLp.bottomMargin = dp(10)
        col.addView(title, titleLp)

        library = AppList(this, true)
        library.background = roundedBg(Color.argb(85, 0, 0, 0), dp(22).toFloat())
        library.setPadding(0, dp(6), 0, dp(6))
        library.onOpen = { app, v -> launch(app, v) }
        library.onMenu = { app -> showAppMenu(app) }
        col.addView(library, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return col
    }

    // ------------------------------------------------------------------ menu d'une app

    private fun showAppMenu(app: AppEntry) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = roundedBg(Color.argb(250, 38, 38, 42), dp(22).toFloat())
        box.setPadding(0, dp(10), 0, dp(10))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(18), dp(6), dp(18), dp(12))
        val img = ImageView(this)
        img.setImageBitmap(IconStore.map[app.key])
        head.addView(img, LinearLayout.LayoutParams(dp(44), dp(44)))
        val name = TextView(this)
        name.text = app.label
        name.setTextColor(Color.WHITE)
        name.textSize = 18f
        name.typeface = Typeface.DEFAULT_BOLD
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        val nameLp = LinearLayout.LayoutParams(0, WRAP, 1f)
        nameLp.leftMargin = dp(14)
        head.addView(name, nameLp)
        box.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        val inHome = store.getList("home").contains(app.key)
        val inDock = store.getList("dock").contains(app.key)

        if (!cfg.allOnHome) addMenuRow(box, dialog, if (inHome) "Retirer de l'écran d'accueil" else "Ajouter à l'écran d'accueil", false) {
            toggleIn("home", app.key, 200)
        }
        if (inHome) {
            val homeList = store.getList("home")
            val idx = homeList.indexOf(app.key)
            if (idx > 0) {
                addMenuRow(box, dialog, "Déplacer avant ◀", false) { moveInHome(app.key, -1) }
            }
            if (idx in 0 until homeList.size - 1) {
                addMenuRow(box, dialog, "Déplacer après ▶", false) { moveInHome(app.key, 1) }
            }
        }
        addMenuRow(box, dialog, if (inDock) "Retirer du Dock" else "Ajouter au Dock", false) {
            toggleIn("dock", app.key, 4)
        }
        addMenuRow(box, dialog, "Informations sur l'app", false) {
            startSafe(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.packageName)))
        }
        addMenuRow(box, dialog, "Désinstaller", true) {
            startSafe(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.packageName)))
        }

        dialog.setContentView(box)
        val w = dialog.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setLayout(dp(300), WRAP)
        }
        dialog.show()
    }

    private fun addMenuRow(box: LinearLayout, dialog: Dialog, text: String, danger: Boolean, action: () -> Unit) {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 16f
        tv.setTextColor(if (danger) Color.parseColor("#FF6B6B") else Color.WHITE)
        tv.setPadding(dp(20), dp(14), dp(20), dp(14))
        tv.setOnClickListener {
            dialog.dismiss()
            action()
        }
        box.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun toggleIn(name: String, key: String, max: Int) {
        val l = store.getList(name)
        if (l.contains(key)) {
            l.remove(key)
        } else {
            if (l.size >= max) {
                toast("Le Dock est plein (4 apps maximum)")
                return
            }
            l.add(key)
        }
        store.setList(name, l)
        if (name == "dock") rebuildDock() else rebuildPager()
    }

    // ------------------------------------------------------------------ recherche (Spotlight)

    private fun buildSpotlight() {
        spotlight = FrameLayout(this)
        spotlight.visibility = View.GONE
        spotlight.setBackgroundColor(Color.argb(238, 18, 18, 22))
        spotlight.setOnClickListener { closeOverlays() }

        spotSheet = LinearLayout(this)
        spotSheet.orientation = LinearLayout.VERTICAL
        spotSheet.setPadding(dp(16), dp(40), dp(16), dp(16))
        spotlight.addView(spotSheet, FrameLayout.LayoutParams(MATCH, MATCH))

        spotInput = EditText(this)
        spotInput.hint = "Rechercher"
        spotInput.setHintTextColor(Color.argb(150, 255, 255, 255))
        spotInput.setTextColor(Color.WHITE)
        spotInput.textSize = 17f
        spotInput.setSingleLine(true)
        spotInput.inputType = InputType.TYPE_CLASS_TEXT
        spotInput.imeOptions = EditorInfo.IME_ACTION_SEARCH
        spotInput.background = roundedBg(Color.argb(60, 255, 255, 255), dp(14).toFloat())
        spotInput.setPadding(dp(16), dp(12), dp(16), dp(12))
        spotSheet.addView(spotInput, LinearLayout.LayoutParams(MATCH, WRAP))

        spotHint = TextView(this)
        spotHint.setTextColor(Color.argb(170, 255, 255, 255))
        spotHint.textSize = 13f
        spotHint.setPadding(dp(6), dp(10), dp(6), dp(6))
        spotSheet.addView(spotHint, LinearLayout.LayoutParams(MATCH, WRAP))

        spotList = AppList(this, false)
        spotList.onOpen = { app, v -> launch(app, v) }
        spotList.onMenu = { app -> showAppMenu(app) }
        spotSheet.addView(spotList, LinearLayout.LayoutParams(MATCH, 0, 1f))

        spotInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                updateSpotlight(s?.toString().orEmpty())
            }
        })
        spotInput.setOnEditorActionListener { _, actionId, _ ->
            val go = actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE
            if (go) submitSpotlight()
            go
        }

        root.addView(spotlight, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun updateSpotlight(q: String) {
        val query = q.trim().lowercase()
        val found: List<AppEntry> = if (query.isEmpty()) {
            emptyList()
        } else {
            allApps.filter { it.label.lowercase().contains(query) }
                .sortedBy { if (it.label.lowercase().startsWith(query)) 0 else 1 }
        }
        spotResults = found
        spotList.submit(found)
        spotHint.text = when {
            query.isEmpty() -> "Tapez le nom d'une application"
            found.isNotEmpty() -> "↵  Ouvrir « " + found[0].label + " »"
            else -> "↵  Rechercher « " + q.trim() + " » sur le web"
        }
    }

    private fun submitSpotlight() {
        val q = spotInput.text.toString().trim()
        if (q.isEmpty()) return
        if (spotResults.isNotEmpty()) {
            launch(spotResults[0], null)
        } else {
            startSafe(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
            closeOverlays()
        }
    }

    private fun openSpotlight() {
        spotSheet.setPadding(dp(16), topInset + dp(16), dp(16), dp(16))
        spotInput.setText("")
        updateSpotlight("")
        showOverlay(spotlight, spotSheet)
        spotInput.requestFocus()
        handler.postDelayed({
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(spotInput, InputMethodManager.SHOW_IMPLICIT)
        }, 250)
    }

    // ------------------------------------------------------------------ centre de notifications

    private fun buildNotifications() {
        notifPanel = FrameLayout(this)
        notifPanel.visibility = View.GONE
        notifPanel.setBackgroundColor(Color.argb(130, 0, 0, 0))
        notifPanel.setOnClickListener { closeOverlays() }

        notifSheet = LinearLayout(this)
        notifSheet.orientation = LinearLayout.VERTICAL
        notifSheet.background = roundedBg(Color.argb(244, 30, 30, 34), dp(26).toFloat())
        notifSheet.setPadding(dp(16), dp(14), dp(16), dp(14))
        notifSheet.isClickable = true

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "Notifications"
        title.setTextColor(Color.WHITE)
        title.textSize = 20f
        title.typeface = Typeface.DEFAULT_BOLD
        header.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        val clear = TextView(this)
        clear.text = "Tout effacer"
        clear.setTextColor(Color.parseColor("#7FB3FF"))
        clear.textSize = 14f
        clear.setPadding(dp(10), dp(8), dp(4), dp(8))
        clear.setOnClickListener {
            try {
                NotifService.instance?.cancelAllNotifications()
            } catch (e: Exception) {
            }
            handler.postDelayed({ refreshNotifications() }, 300)
        }
        header.addView(clear, LinearLayout.LayoutParams(WRAP, WRAP))
        notifSheet.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        notifBox = LinearLayout(this)
        notifBox.orientation = LinearLayout.VERTICAL
        scroll.addView(notifBox, FrameLayout.LayoutParams(MATCH, WRAP))
        val scrollHeight = (resources.displayMetrics.heightPixels * 0.5f).toInt()
        notifSheet.addView(scroll, LinearLayout.LayoutParams(MATCH, scrollHeight))

        val lp = FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP)
        lp.leftMargin = dp(10)
        lp.rightMargin = dp(10)
        lp.topMargin = dp(40)
        notifPanel.addView(notifSheet, lp)
        root.addView(notifPanel, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun notifAccessGranted(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(packageName)
    }

    private fun refreshNotifications() {
        notifBox.removeAllViews()

        if (!notifAccessGranted()) {
            val msg = TextView(this)
            msg.text = "Pour voir vos notifications ici, autorisez augustart à les lire."
            msg.setTextColor(Color.argb(210, 255, 255, 255))
            msg.textSize = 15f
            msg.setPadding(0, dp(14), 0, dp(10))
            notifBox.addView(msg, LinearLayout.LayoutParams(MATCH, WRAP))

            val btn = TextView(this)
            btn.text = "Autoriser l'accès"
            btn.setTextColor(Color.WHITE)
            btn.textSize = 15f
            btn.gravity = Gravity.CENTER
            btn.background = roundedBg(Color.parseColor("#2F6BFF"), dp(14).toFloat())
            btn.setOnClickListener {
                closeOverlays()
                startSafe(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            notifBox.addView(btn, LinearLayout.LayoutParams(MATCH, dp(46)))
            return
        }

        val list = ArrayList<StatusBarNotification>()
        val svc = NotifService.instance
        if (svc != null) {
            try {
                val active = svc.activeNotifications
                if (active != null) {
                    for (n in active) {
                        val summary = (n.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0
                        if (n.packageName != packageName && !summary) list.add(n)
                    }
                }
            } catch (e: Exception) {
            }
        }
        list.sortByDescending { it.postTime }

        if (list.isEmpty()) {
            val none = TextView(this)
            none.text = "Aucune notification"
            none.setTextColor(Color.argb(190, 255, 255, 255))
            none.textSize = 15f
            none.setPadding(0, dp(16), 0, dp(10))
            notifBox.addView(none, LinearLayout.LayoutParams(MATCH, WRAP))
            return
        }
        for (sbn in list) {
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dp(8)
            notifBox.addView(buildNotifRow(sbn), lp)
        }
    }

    private fun buildNotifRow(sbn: StatusBarNotification): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = roundedBg(Color.argb(60, 255, 255, 255), dp(16).toFloat())
        row.setPadding(dp(12), dp(10), dp(12), dp(10))

        val icon = ImageView(this)
        try {
            icon.setImageDrawable(packageManager.getApplicationIcon(sbn.packageName))
        } catch (e: Exception) {
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))

        var appName = sbn.packageName
        try {
            appName = packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
        }
        val extras = sbn.notification.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras?.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val appTv = TextView(this)
        appTv.text = appName
        appTv.setTextColor(Color.argb(160, 255, 255, 255))
        appTv.textSize = 11f
        appTv.maxLines = 1
        col.addView(appTv, LinearLayout.LayoutParams(MATCH, WRAP))
        val titleTv = TextView(this)
        titleTv.text = title
        titleTv.setTextColor(Color.WHITE)
        titleTv.textSize = 15f
        titleTv.typeface = Typeface.DEFAULT_BOLD
        titleTv.maxLines = 1
        titleTv.ellipsize = TextUtils.TruncateAt.END
        col.addView(titleTv, LinearLayout.LayoutParams(MATCH, WRAP))
        val textTv = TextView(this)
        textTv.text = text
        textTv.setTextColor(Color.argb(210, 255, 255, 255))
        textTv.textSize = 14f
        textTv.maxLines = 2
        textTv.ellipsize = TextUtils.TruncateAt.END
        col.addView(textTv, LinearLayout.LayoutParams(MATCH, WRAP))

        val colLp = LinearLayout.LayoutParams(0, WRAP, 1f)
        colLp.leftMargin = dp(12)
        row.addView(col, colLp)

        row.setOnClickListener {
            try {
                sbn.notification.contentIntent?.send()
            } catch (e: Exception) {
            }
            try {
                NotifService.instance?.cancelNotification(sbn.key)
            } catch (e: Exception) {
            }
            closeOverlays()
        }
        return row
    }

    private fun openNotifications() {
        placeTop(notifSheet)
        refreshNotifications()
        showOverlay(notifPanel, notifSheet)
    }

    // ------------------------------------------------------------------ centre de contrôle

    private fun buildControl() {
        controlPanel = FrameLayout(this)
        controlPanel.visibility = View.GONE
        controlPanel.setBackgroundColor(Color.argb(130, 0, 0, 0))
        controlPanel.setOnClickListener { closeOverlays() }

        controlSheet = LinearLayout(this)
        controlSheet.orientation = LinearLayout.VERTICAL
        controlSheet.background = roundedBg(Color.argb(244, 30, 30, 34), dp(26).toFloat())
        controlSheet.setPadding(dp(16), dp(16), dp(16), dp(16))
        controlSheet.isClickable = true

        val title = TextView(this)
        title.text = "Centre de contrôle"
        title.setTextColor(Color.WHITE)
        title.textSize = 18f
        title.typeface = Typeface.DEFAULT_BOLD
        val titleLp = LinearLayout.LayoutParams(MATCH, WRAP)
        titleLp.bottomMargin = dp(8)
        controlSheet.addView(title, titleLp)

        val row1 = tileRow()
        row1.addView(tile("📶", "Wi-Fi", { wifiOn() }, { toggleWifi() }), tileLp())
        row1.addView(tile("🔵", "Bluetooth", { btOn() }, { openSettingsAndClose(Settings.ACTION_BLUETOOTH_SETTINGS) }), tileLp())
        row1.addView(tile("✈️", "Avion", { airplaneOn() }, { openSettingsAndClose(Settings.ACTION_AIRPLANE_MODE_SETTINGS) }), tileLp())
        row1.addView(tile("🔦", "Lampe", { torchOn }, { toggleTorch() }), tileLp())
        controlSheet.addView(row1, LinearLayout.LayoutParams(MATCH, WRAP))

        val row2 = tileRow()
        row2.addView(tile("📡", "Données", { false }, { dataSettings() }), tileLp())
        row2.addView(tile("🔄", "Rotation", { rotationOn() }, { toggleRotation() }), tileLp())
        row2.addView(tile("🖼️", "Fond d'écran", { false }, { wallpaperPicker() }), tileLp())
        row2.addView(tile("⚙️", "Réglages", { false }, { openSettingsAndClose(Settings.ACTION_SETTINGS) }), tileLp())
        controlSheet.addView(row2, LinearLayout.LayoutParams(MATCH, WRAP))

        // Luminosité
        brightBar = SeekBar(this)
        brightBar.max = 255
        brightBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                if (!Settings.System.canWrite(this@MainActivity)) {
                    requestWriteSettings()
                    return
                }
                try {
                    Settings.System.putInt(
                        contentResolver,
                        Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                    )
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, Math.max(1, progress))
                } catch (e: Exception) {
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        val brightLp = LinearLayout.LayoutParams(MATCH, WRAP)
        brightLp.topMargin = dp(12)
        controlSheet.addView(sliderRow("☀️", brightBar), brightLp)

        // Volume
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        volumeBar = SeekBar(this)
        volumeBar.max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        volumeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                try {
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
                } catch (e: Exception) {
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        val volLp = LinearLayout.LayoutParams(MATCH, WRAP)
        volLp.topMargin = dp(6)
        controlSheet.addView(sliderRow("🔊", volumeBar), volLp)

        val settingsBtn = TextView(this)
        settingsBtn.text = "⚙️  Réglages augustart"
        settingsBtn.setTextColor(Color.WHITE)
        settingsBtn.textSize = 15f
        settingsBtn.typeface = Typeface.DEFAULT_BOLD
        settingsBtn.gravity = Gravity.CENTER
        settingsBtn.background = roundedBg(Color.argb(70, 255, 255, 255), dp(14).toFloat())
        settingsBtn.setOnClickListener { openSettings() }
        val setLp = LinearLayout.LayoutParams(MATCH, dp(46))
        setLp.topMargin = dp(14)
        controlSheet.addView(settingsBtn, setLp)

        val lp = FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP)
        lp.leftMargin = dp(10)
        lp.rightMargin = dp(10)
        lp.topMargin = dp(40)
        controlPanel.addView(controlSheet, lp)
        root.addView(controlPanel, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun tileRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        return row
    }

    private fun tileLp(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)

    private fun sliderRow(emoji: String, bar: SeekBar): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val e = TextView(this)
        e.text = emoji
        e.textSize = 20f
        e.setTextColor(Color.WHITE)
        row.addView(e, LinearLayout.LayoutParams(dp(36), WRAP))
        bar.progressTintList = ColorStateList.valueOf(Color.WHITE)
        bar.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        row.addView(bar, LinearLayout.LayoutParams(0, WRAP, 1f))
        return row
    }

    private fun tile(emoji: String, label: String, active: () -> Boolean, onClick: () -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(0, dp(6), 0, dp(6))

        val dot = TextView(this)
        dot.text = emoji
        dot.textSize = 22f
        dot.gravity = Gravity.CENTER
        box.addView(dot, LinearLayout.LayoutParams(dp(56), dp(56)))

        val name = TextView(this)
        name.text = label
        name.setTextColor(Color.argb(220, 255, 255, 255))
        name.textSize = 11f
        name.maxLines = 1
        name.gravity = Gravity.CENTER
        val nameLp = LinearLayout.LayoutParams(WRAP, WRAP)
        nameLp.topMargin = dp(5)
        box.addView(name, nameLp)

        val refresh: () -> Unit = {
            val color = if (active()) Color.argb(235, 255, 255, 255) else Color.argb(85, 255, 255, 255)
            dot.background = ovalBg(color)
        }
        refresh()
        tileRefreshers.add(refresh)

        box.setOnClickListener {
            onClick()
            handler.postDelayed({ refresh() }, 250)
        }
        return box
    }

    private fun openControl() {
        askedWrite = false
        placeTop(controlSheet)
        try {
            brightBar.progress = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) {
            brightBar.progress = 128
        }
        try {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            volumeBar.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        } catch (e: Exception) {
        }
        for (r in tileRefreshers) {
            r()
        }
        showOverlay(controlPanel, controlSheet)
    }

    private fun wifiOn(): Boolean {
        return try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wm.isWifiEnabled
        } catch (e: Exception) {
            false
        }
    }

    private fun toggleWifi() {
        if (Build.VERSION.SDK_INT >= 29) {
            // Depuis Android 10, une application ne peut plus activer le Wi-Fi seule : on ouvre le panneau du système.
            openSettingsAndClose(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        } else {
            try {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                wm.isWifiEnabled = !wm.isWifiEnabled
            } catch (e: Exception) {
                openSettingsAndClose(Settings.ACTION_WIFI_SETTINGS)
            }
        }
    }

    private fun btOn(): Boolean {
        return try {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            adapter != null && adapter.isEnabled
        } catch (e: Exception) {
            false
        }
    }

    private fun airplaneOn(): Boolean {
        return try {
            Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        } catch (e: Exception) {
            false
        }
    }

    private fun rotationOn(): Boolean {
        return try {
            Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
        } catch (e: Exception) {
            false
        }
    }

    private fun toggleRotation() {
        if (!Settings.System.canWrite(this)) {
            requestWriteSettings()
            return
        }
        try {
            val cur = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (cur == 1) 0 else 1)
        } catch (e: Exception) {
        }
    }

    private fun toggleTorch() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var id: String? = null
            for (cid in cm.cameraIdList) {
                val ch = cm.getCameraCharacteristics(cid)
                val flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE)
                val facing = ch.get(CameraCharacteristics.LENS_FACING)
                if (flash == true && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    id = cid
                    break
                }
            }
            if (id == null) {
                toast("Pas de lampe sur cet appareil")
                return
            }
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
        } catch (e: Exception) {
            torchOn = false
            toast("Lampe indisponible")
        }
    }

    private fun dataSettings() {
        closeOverlays()
        if (!startSafe(Intent(Settings.ACTION_DATA_ROAMING_SETTINGS))) {
            startSafe(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        }
    }

    private fun wallpaperPicker() {
        closeOverlays()
        startSafe(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Fond d'écran"))
    }

    private fun openSettingsAndClose(action: String) {
        closeOverlays()
        startSafe(Intent(action))
    }

    private fun requestWriteSettings() {
        if (askedWrite) return
        askedWrite = true
        toast("Autorisez augustart à modifier les réglages du système")
        closeOverlays()
        startSafe(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + packageName)))
    }

    // ------------------------------------------------------------------ réglages augustart

    private fun buildSettings() {
        settings = SettingsPanel(this, cfg, object : SettingsPanel.Actions {
            override fun onPreset() = reloadStyle()
            override fun onIconStyle() = reloadStyle()
            override fun onLayout() = rebuildAll()
            override fun onEffect() {
                pager.effect = cfg.effect
                pager.refreshEffects()
            }
            override fun onApplyWallpaper() = applyLiveWallpaper()
            override fun onResetHome() {
                store.setList("home", emptyList())
                rebuildPager()
                toast("Écran d'accueil réinitialisé")
            }
            override fun onClose() = closeOverlays()
        })
        root.addView(settings.view, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun openSettings() {
        closeOverlays()
        settings.refresh()
        showOverlay(settings.view, settings.sheet)
    }

    /** Recharge les icônes (forme ou taille changée) puis redessine l'accueil. */
    private fun reloadStyle() {
        pager.effect = cfg.effect
        iconPx = dp(cfg.iconDp())
        forceRebuild = true
        loadApps()
    }

    /** Déplace une app d'une case dans l'accueil (delta = -1 avant, +1 après). */
    private fun moveInHome(key: String, delta: Int) {
        val l = store.getList("home")
        val idx = l.indexOf(key)
        val target = idx + delta
        if (idx < 0 || target < 0 || target >= l.size) return
        java.util.Collections.swap(l, idx, target)
        store.setList("home", l)
        rebuildPager()
    }

    /** Ouvre le choix de fond d'écran animé, avec augustart déjà sélectionné. */
    private fun applyLiveWallpaper() {
        closeOverlays()
        try {
            val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            i.putExtra(
                WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                ComponentName(this, AugustartWallpaper::class.java)
            )
            startActivity(i)
        } catch (e: Exception) {
            startSafe(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }

    // ------------------------------------------------------------------ panneaux (affichage / fermeture)

    private fun placeTop(sheet: View) {
        val lp = sheet.layoutParams as FrameLayout.LayoutParams
        lp.topMargin = topInset + dp(8)
        sheet.layoutParams = lp
    }

    private fun showOverlay(overlay: View, sheet: View) {
        overlay.animate().cancel()
        sheet.animate().cancel()
        overlay.alpha = 0f
        overlay.visibility = View.VISIBLE
        sheet.translationY = -dp(30).toFloat()
        overlay.animate().alpha(1f).setDuration(180).start()
        sheet.animate().translationY(0f).setDuration(220).start()
    }

    private fun hideOverlay(overlay: View) {
        if (overlay.visibility != View.VISIBLE) return
        overlay.animate().cancel()
        overlay.animate()
            .alpha(0f)
            .setDuration(150)
            .withEndAction {
                overlay.visibility = View.GONE
                overlay.alpha = 1f
            }
            .start()
    }

    private fun closeOverlays() {
        hideKeyboard()
        hideOverlay(spotlight)
        hideOverlay(notifPanel)
        hideOverlay(controlPanel)
        hideOverlay(settings.view)
    }

    private fun isOverlayVisible(): Boolean {
        return spotlight.visibility == View.VISIBLE ||
            notifPanel.visibility == View.VISIBLE ||
            controlPanel.visibility == View.VISIBLE ||
            settings.view.visibility == View.VISIBLE
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(root.windowToken, 0)
    }
}
