plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.augustart.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.augustart.launcher"
        minSdk = 24
        targetSdk = 35
        versionCode = 3
        versionName = "3.0"
    }

    // Clé de signature fixe : chaque nouvelle version s'installe par-dessus la précédente
    // sans devoir désinstaller l'application (clé personnelle, pas pour le Play Store).
    signingConfigs {
        getByName("debug") {
            storeFile = file("augustart-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
