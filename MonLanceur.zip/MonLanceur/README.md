# augustart launcher 3.0

Un écran d'accueil Android façon iPhone, avec des réglages pour changer de style.

## Ce que fait augustart

- **Écran d'accueil** paginé avec horloge, date, batterie et vos apps
- **Styles prêts à l'emploi** dans les réglages : iPhone, Samsung, Pixel, Xiaomi, Minimal
- **Forme des icônes** : squircle, rond, arrondi, carré ; **taille** petite, moyenne ou grande
- **Colonnes** : 4 ou 5 ; noms des apps affichés ou cachés ; Dock affiché ou caché
- **Toutes les apps sur l'accueil** (style Xiaomi) : pas de Bibliothèque
- **Animation entre les pages** : aucune, zoom, cube ou pile
- **Fond d'écran animé** : aurore, étoiles, bulles ou vagues (le fond se déplace avec les pages)
- **Bibliothèque d'apps** : la dernière page, toutes vos apps classées de A à Z
- **Recherche (Spotlight)** : glissez vers le bas au milieu de l'écran, ou touchez « Rechercher »
- **Centre de notifications** : glissez vers le bas en haut à **gauche** (autorisation demandée au premier usage)
- **Centre de contrôle** : glissez vers le bas en haut à **droite** (Wi-Fi, Bluetooth, mode avion, lampe, données, rotation, luminosité, volume, accès aux réglages)
- **Appui long sur une app** : ajouter ou retirer de l'accueil ou du Dock, déplacer avant ou après, informations, désinstaller
- **Appui long sur un espace vide** de l'accueil : ouvre les réglages augustart
- **Glisser vers le haut** sur l'accueil : va directement à la Bibliothèque (ou à la recherche si elle est désactivée)

## Mettre à jour l'application (depuis le téléphone)

1. Ouvrez votre dépôt sur github.com, touchez **Add file**, puis **Upload files**.
2. Choisissez le nouveau **MonLanceur.zip** (même nom que l'ancien : il le remplace), puis **Commit changes**.
3. Ouvrez l'onglet **Actions** : la compilation démarre toute seule (3 à 6 minutes).
4. Quand la ligne est verte, touchez-la, puis téléchargez **MonLanceur-apk** tout en bas. Extrayez le zip et installez **app-debug.apk**.

L'application est toujours signée avec la même clé : une nouvelle version s'installe par-dessus la précédente.

## Au premier lancement

1. Appuyez sur le bouton **Accueil** et choisissez **augustart**, puis **Toujours**.
2. Pour la luminosité et la rotation : le centre de contrôle demandera l'autorisation « Modifier les réglages du système ».
3. Pour les notifications : touchez « Autoriser l'accès » dans le centre de notifications.
4. Pour le fond animé : ouvrez les réglages augustart (appui long sur l'accueil), puis touchez **Appliquer le fond animé** et confirmez.

## Revenir à l'ancien écran d'accueil

**Paramètres > Applications > Applications par défaut > Application d'accueil**, puis choisissez l'ancien.

## Limites d'Android

- Un launcher ne peut pas remplacer les écrans du système lui-même (barre de notifications d'Android, application Réglages, écran de verrouillage) sans accès root. augustart propose donc ses propres versions à l'intérieur du launcher. Le panneau d'Android reste disponible en glissant depuis le tout haut de l'écran.
- Le fond animé se change depuis le choix de fonds d'écran d'Android : Android demande toujours une confirmation.
- Le défilement du fond d'écran avec les pages dépend du téléphone : sur certains modèles, le fond reste fixe.
- Le Wi-Fi ne peut plus être activé directement par une application depuis Android 10 : le bouton ouvre le panneau du système.

## Où modifier quoi

| Fichier | Contenu |
|---|---|
| `app/src/main/java/com/augustart/launcher/MainActivity.kt` | Comportement, écran d'accueil, menus, centres |
| `app/src/main/java/com/augustart/launcher/SettingsPanel.kt` | Panneau des réglages |
| `app/src/main/java/com/augustart/launcher/Config.kt` | Réglages et styles prêts à l'emploi (iPhone, Samsung...) |
| `app/src/main/java/com/augustart/launcher/Store.kt` | Sauvegarde des réglages et des apps |
| `app/src/main/java/com/augustart/launcher/IconRenderer.kt` | Forme des icônes |
| `app/src/main/java/com/augustart/launcher/Views.kt` | Grille, pages, effets entre les pages, listes |
| `app/src/main/java/com/augustart/launcher/AugustartWallpaper.kt` | Fond d'écran animé (4 scènes) |
| `app/src/main/res/drawable/ic_launcher_*.xml` | Logo |
| `app/src/main/res/xml/augustart_wallpaper.xml` | Description du fond d'écran animé |

## Avertissement

Cette version n'a pas encore été compilée sur un téléphone au moment de sa création. Si la compilation échoue, copiez la ligne rouge de l'onglet Actions et envoyez-la pour correction.
